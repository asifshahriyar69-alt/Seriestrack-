const apiKey = "7a64a691";

// হোমপেজ তালিকা
const popularMoviesTitles = ["Inception", "Interstellar", "The Dark Knight"];
const popularSeriesTitles = ["Game of Thrones", "Breaking Bad", "Stranger Things"];
const recentMoviesTitles = ["Avatar: The Way of Water", "Oppenheimer", "Barbie"];
const recentSeriesTitles = ["The Last of Us", "House of the Dragon", "Wednesday"];

const popularMovies = document.getElementById("popularMovies");
const popularSeries = document.getElementById("popularSeries");
const recentMovies = document.getElementById("recentMovies");
const recentSeries = document.getElementById("recentSeries");

const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");

const detailsSection = document.getElementById("detailsSection");
const backBtn = document.getElementById("backBtn");

const detailsPoster = document.getElementById("detailsPoster");
const detailsTitle   = document.getElementById("detailsTitle");
const detailsYear    = document.getElementById("detailsYear");
const detailsRating  = document.getElementById("detailsRating");
const detailsCast    = document.getElementById("detailsCast");
const episodesList   = document.getElementById("episodesList");

// কাজ: কার্ড লোড
function loadCards(titles, container) {
  container.innerHTML = "";
  titles.forEach(title => {
    fetch(`https://www.omdbapi.com/?t=${encodeURIComponent(title)}&apikey=${apiKey}`)
      .then(res => res.json())
      .then(data => {
        if(data.Response === "True") {
          const card = document.createElement("div");
          card.className = "card";
          card.innerHTML = `
            <img src="${data.Poster !== "N/A" ? data.Poster : 'https://via.placeholder.com/180x270?text=No+Image'}" alt="${data.Title}">
            <h3>${data.Title}</h3>
          `;
          card.addEventListener("click", () => showDetails(data.imdbID, data.Type));
          container.appendChild(card);
        }
      });
  });
}

loadCards(popularMoviesTitles, popularMovies);
loadCards(popularSeriesTitles, popularSeries);
loadCards(recentMoviesTitles, recentMovies);
loadCards(recentSeriesTitles, recentSeries);

// সার্চ  
searchBtn.addEventListener("click", () => {
  const query = searchInput.value.trim();
  if(query) {
    // খুঁজে প্রথম ফলাফল পায়
    fetch(`https://www.omdbapi.com/?s=${encodeURIComponent(query)}&apikey=${apiKey}`)
      .then(res => res.json())
      .then(data => {
        if(data.Response === "True" && data.Search.length > 0) {
          const first = data.Search[0];
          showDetails(first.imdbID, first.Type);
        } else {
          alert("Movie/Series not found!");
        }
      });
  }
});

// বিস্তারিত দেখুন
function showDetails(imdbID, type) {
  fetch(`https://www.omdbapi.com/?i=${imdbID}&apikey=${apiKey}&plot=short`)
    .then(res => res.json())
    .then(data => {
      if(data.Response === "True") {
        // হোমপেজ সেকশন লুকান
        document.querySelectorAll('main > section').forEach(sec => sec.classList.add("hidden"));
        detailsSection.classList.remove("hidden");

        detailsPoster.src = data.Poster !== "N/A" ? data.Poster : 'https://via.placeholder.com/250x350?text=No+Image';
        detailsTitle.textContent = data.Title;
        detailsYear.textContent  = data.Year;
        detailsRating.textContent= data.imdbRating;

        // Cast
        detailsCast.innerHTML = "";
        const actorsArr = data.Actors.split(",").map(s => s.trim());
        actorsArr.forEach(actor => {
          const div = document.createElement("div");
          div.className = "cast-item";
          div.innerHTML = `
            <img src="https://via.placeholder.com/80?text=Photo" alt="${actor}">
            <p>${actor}</p>
          `;
          detailsCast.appendChild(div);
        });

        // Episodes if series
        if(type === "series" && data.totalSeasons) {
          episodesList.innerHTML = "";
          const totalSeasons = parseInt(data.totalSeasons);
          for(let s=1; s<= totalSeasons; s++){
            const seasonHeader = document.createElement("h4");
            seasonHeader.textContent = `Season ${s}`;
            episodesList.appendChild(seasonHeader);

            fetch(`https://www.omdbapi.com/?i=${imdbID}&apikey=${apiKey}&season=${s}`)
              .then(res2 => res2.json())
              .then(seasonData => {
                if(seasonData.Response === "True" && seasonData.Episodes) {
                  seasonData.Episodes.forEach(ep => {
                    const epDiv = document.createElement("div");
                    epDiv.className = "episode-item";
                    epDiv.innerHTML = `<span>${ep.Episode}. ${ep.Title}</span> <span>${ep.imdbRating ? ep.imdbRating + " ⭐" : "N/A"}</span>`;
                    episodesList.appendChild(epDiv);
                  });
                } else {
                  // কোনো এপিসোড তথ্য নেই
                  const info = document.createElement("p");
                  info.textContent = `No episode details for Season ${s}`;
                  episodesList.appendChild(info);
                }
              });
          }
        } else {
          episodesList.innerHTML = "<p>Episode details not available</p>";
        }

      } else {
        alert("Details not found!");
      }
    });
}

// Back button
backBtn.addEventListener("click", () => {
  detailsSection.classList.add("hidden");
  document.querySelectorAll('main > section').forEach(sec => sec.classList.remove("hidden"));
  searchInput.value = "";
});